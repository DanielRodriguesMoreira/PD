


/**
 * @author Daniel Moreira
 * @author Hugo Santos
 * @author Tiago Santos 
 */

public class Main {
    public static void main(String[] args) {
        MonitorGUI gui = new MonitorGUI();
    }
}
